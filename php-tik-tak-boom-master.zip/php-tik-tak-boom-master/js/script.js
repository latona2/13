

document.getElementById('start').onclick = () => {
    tikTakBoom.init(
        tasks,
        document.getElementById('timerField'),
        document.getElementById('gameStatusField'),
        document.getElementById('questionField'),
        document.getElementById('answer1'),
        document.getElementById('answer2'),
    )
    tikTakBoom.run();
}



function showhide(id) {
       	var e = document.getElementById(id);
       	e.style.display = (e.style.display == 'block') ? 'none' : 'block';
		document.getElementById("start").innerHTML="ЗАВЕРШИТЬ";
		
		
		
		
		
     }


