const tasks = `

    [
        {
            "question": "2 * 2 = ",
            "answer1": { "result": true, "value": "4" },
            "answer2": { "result": false, "value": "3" }
        },
        {
            "question": "Как зовут крокодила, лучшего друга Чебурашки?",
            "answer1": { "result": false, "value": "Данди" },
            "answer2": { "result": true, "value": "Гена" }
        },
        {
            "question": "Мы часто произносим фразу «век живи — век учись», но никогда не договариваем ее до конца. Итак, «век живи  — век учись тому…»",
            "answer1": { "result": false, "value": "как следует пить" },
            "answer2": { "result": true, "value": "как следует жить" }
        },
		  {
            "question": "Основой для «Сказки о рыбаке и рыбке Пушкина послужила сказка братьев Гримм «Рыбак и его жена». В ней немецкая «коллега» нашей старухи превратилась в:",
            "answer1": { "result": false, "value": "Директора рыбзавода" },
            "answer2": { "result": true, "value": "Папу Римского" }
        },
		  {
            "question": "Российский мультфильм, удостоенный «Оскара», — это…",
            "answer1": { "result": false, "value": "«Простоквашино»" },
            "answer2": { "result": true, "value": "«Старик и море»" }
        },
		  {
             "question": "Кто из знаменитых художников за жизнь продал всего одну картину? ",
            "answer1": { "result": false, "value": "Пьер Огюст Ренуар" },
            "answer2": { "result": true, "value": "Винсент Ван Гог" }
        },
		  {"question": "Что в Российской империи было вещевым эквивалентом денег?",
            "answer1": { "result": false, "value": "Табак" },
            "answer2": { "result": true, "value": "Шкуры пушных зверей" }
        },
		  {
            "question": "Страусы от опасности прячут голову в песок",
            "answer1": { "result": false, "value": "Да" },
            "answer2": { "result": true, "value": "Нет" }
        },
		{
            "question": "Бананы растут на пальмах",
            "answer1": { "result": false, "value": "Да" },
            "answer2": { "result": true, "value": "Нет" }
        },
		{
            "question": "Эйнштейн был двоечником.",
            "answer1": { "result": false, "value": "Да" },
            "answer2": { "result": true, "value": "Нет" }
        },
		{
            "question": "Курица может жить без головы.",
            "answer1": { "result": false, "value": "Да" },
            "answer2": { "result": true, "value": "Нет" }
        },
		{
            "question": "Молния не может ударить дважды в одно и то же место.",
            "answer1": { "result": false, "value": "Да" },
            "answer2": { "result": true, "value": "Нет" }
        },
		{
            "question": "Верблюды накапливают в горбах воду.",
            "answer1": { "result": false, "value": "Нет" },
            "answer2": { "result": true, "value": "Да" }
        },
		{
            "question": "Фраза «И все-таки она вертится!» принадлежит Галилею.",
            "answer1": { "result": false, "value": "Да" },
            "answer2": { "result": true, "value": "Нет" }
        },{
            "question": "Если взять в руку лягушку — появится бородавка.",
            "answer1": { "result": false, "value": "Да" },
            "answer2": { "result": true, "value": "Нет" }
        },{
            "question": "Страусы от опасности прячут голову в песок",
            "answer1": { "result": false, "value": "Да" },
            "answer2": { "result": true, "value": "Нет" }
        },{
            "question": "Нервные клетки не восстанавливаются.",
            "answer1": { "result": false, "value": "Да" },
            "answer2": { "result": true, "value": "Нет" }
        },{
            "question": "Если много смеяться — на лице появятся мимические морщины.",
            "answer1": { "result": false, "value": "Да" },
            "answer2": { "result": true, "value": "Нет" }
        },
		{
            "question": "Страусы от опасности прячут голову в песок",
            "answer1": { "result": false, "value": "Да" },
            "answer2": { "result": true, "value": "Нет" }
        },
		{
            "question": "Великая Китайская стена — единственный рукотворный объект на Земле, видимый из космоса.",
            "answer1": { "result": false, "value": "Да" },
            "answer2": { "result": true, "value": "Нет" }
        },
		{
            "question": "Страусы от опасности прячут голову в песок",
            "answer1": { "result": false, "value": "Да" },
            "answer2": { "result": true, "value": "Нет" }
        },
		{
            "question": "Как называют жителей города Смоленска в РФ?",
            "answer1": { "result": false, "value": "Смолянки" },
            "answer2": { "result": true, "value": "Смоляне" }
        },
		{
            "question": "Страусы от опасности прячут голову в песок",
            "answer1": { "result": false, "value": "Да" },
            "answer2": { "result": true, "value": "Нет" }
        },
		{
            "question": "Страусы от опасности прячут голову в песок",
            "answer1": { "result": false, "value": "Да" },
            "answer2": { "result": true, "value": "Нет" }
        },
		{
            "question": "Согласно пословице, до какой столицы может довести язык?",
            "answer1": { "result": false, "value": "Китай" },
            "answer2": { "result": true, "value": "Киев" }
        },
		{
            "question": "Страусы от опасности прячут голову в песок",
            "answer1": { "result": false, "value": "Да" },
            "answer2": { "result": true, "value": "Нет" }
        },
		{
            "question": "В это озеро в России впадает 336 рек, а вытекает только одна. Что это за озеро?",
            "answer1": { "result": false, "value": "Комо" },
            "answer2": { "result": true, "value": "Байкал" }
        },
		{
            "question": "Страусы от опасности прячут голову в песок",
            "answer1": { "result": false, "value": "Да" },
            "answer2": { "result": true, "value": "Нет" }
        },
		        {
            "question": "Кто из президентов США написал свой собственный рассказ про Шерлока Холмса??",
            "answer1": { "result": false, "value": "Джон Кеннеди" },
            "answer2": { "result": true, "value": "Франклин Рузвельт" }
        },
        {
            "question": "Столица Италии?",
            "answer1": { "result": false, "value": "Ватикан" },
            "answer2": { "result": true, "value": "Рим" }
        }
    ]
`;
